configuration installAzurePS 
{ 
    node "localhost"
    { 
        Script AzurePS
        {
            Set-Script = {
                $LogFile = "c:\azure-bootstrap-log.txt"
                Function LogWrite($logstring)
                {
                    Write-Host $logstring
                    Add-Content $LogFile -value $logstring
                }
                LogWrite "Installing NuGet..."
                Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Scope AllUsers -Verbose -Force
                LogWrite "Installing AzureRm module..."
                Install-Module -Name AzureRM -Scope AllUsers -Verbose -Force
                LogWrite "installing done..."
            }
            Test-Script = {
                !((Get-Module -Name AzureRM.Profile -ListAvailable) -eq $null)
            }
            Get-Script = {
                @{ Result = (Get-Module -Name AzureRM.Profile -ListAvailable).Version.ToString() } 
            }
        }
    } 
}