configuration installAzurePS 
{ 
    Node "localhost"
    { 
        Script AzurePS
        {
            SetScript = {
                Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Scope AllUsers -Verbose -Force
                Install-Module -Name AzureRM -Scope AllUsers -Verbose -Force
            }
            TestScript = {
                !((Get-Module -Name AzureRM.Profile -ListAvailable) -eq $null)
            }
            GetScript = {
                @{ Result = (Get-Module -Name AzureRM.Profile -ListAvailable).Version.ToString() } 
            }
        }
    } 
}